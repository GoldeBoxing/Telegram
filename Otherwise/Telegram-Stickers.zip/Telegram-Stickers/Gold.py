GT1 = '\x1b[1;92m\x1b[38;5;46m'
GT2 = '\x1b[1;92m\x1b[38;5;50m'
GT3 = '\x1b[38;5;196m'
GT4 = '\x1b[1;92m\x1b[38;5;210m'
GT5 = '\x1b[38;5;90m'
GT6 = '\x1b[38;5;93m'
GT9 = '\x1b[38;5;123m'
m1 = '\x1b[38;5;196m'
G20 = '\x1b[1;92m\x1b[38;5;212m'
print(f'{GT2}[ {GT1}By{GT2}] {GT3}- {GT4}GoLdEn {GT3}- {GT9}@rrrrrF {GT5}.\n{m1}----------------------{G20}')
import os,random,asyncio;from PIL import Image;from telethon import *;import requests,os,time;from telethon import *;import os,base64,zlib,pip,urllib,platform,math,shutil,random,uuid,string,hashlib,json,sys
P1='api-id';P2='api-hash'# - [ > الايبيـات < ]
N1='🎄 - @rrrrrF : @N_9_N_6'# - [ > اسـم الـحزمـة < ]
N2='GoldenVerEmoji'# - [ > اسـم الـرابط < ]
EE=['🐉','✨','🎗','🤍']# - [ > تكدر تعدل عليهم او تتركهم < ]
X1='G-PHOTO';X2='G-EXPRES'
os.makedirs(X2,exist_ok=True)
for GFILE in os.listdir(X1):
    if GFILE.lower().endswith(('.png','.jpg','.jpeg')):
        GIMAGE=os.path.join(X1,GFILE)
        x=Image.open(GIMAGE)
        x=x.resize((100,100))
        GPU=os.path.join(X2,f'{os.path.splitext(GFILE)[0]}.png')
        x.save(GPU,'PNG')
i=TelegramClient('see',P1,P2)
async def G():
    await i.start()
    BOY=await i.get_entity('@Stickers')
    await i.send_message(BOY,'/newemojipack')
    async for M in i.iter_messages(BOY,limit=1):
        if 'Yay! A new set of custom emoji.' in M.message:
            await i.send_message(BOY,'Static emoji')
            async for M in i.iter_messages(BOY,limit=1):
                if 'Yay! A new set of static emoji.' in M.message:
                    await i.send_message(BOY,N1)
                    async for M in i.iter_messages(BOY,limit=1):
                        if 'send me the custom emoji.' in M.message:
                            for xFi in os.listdir(X2):
                                GIMAGE=os.path.join(X2,xFi)
                                await i.send_file(BOY,GIMAGE,force_document=True)
                                emoj=random.choice(EE)
                                await i.send_message(BOY,emoj)
                                async for M in i.iter_messages(BOY,limit=1):
                                    if 'Congratulations' not in M.message:
                                        break
                            await i.send_message(BOY,'/publish')
                            async for M in i.iter_messages(BOY,limit=1):
                                if 'You can send me a custom emoji' in M.message:
                                    await i.send_message(BOY,'/skip')
                                    async for M in i.iter_messages(BOY,limit=1):
                                        if 'Please provide a short name for your emoji set.' in M.message:
                                            await i.send_message(BOY,N2)
                                            async for M in i.iter_messages(BOY,limit=1):
                                                if 'Sorry,this short name is unacceptable.' in M.message or 'Sorry, this short name is already taken.' in M.message:
                                                    await i.send_message(BOY,N2+'123')
                                                    async for M in i.iter_messages(BOY,limit=1):
                                                        if 'Kaboom!' in M.message:
                                                            print('- [Done] -')
with i:
    i.loop.run_until_complete(G())